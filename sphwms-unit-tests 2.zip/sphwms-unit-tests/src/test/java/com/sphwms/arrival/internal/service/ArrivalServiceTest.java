package com.sphwms.arrival.internal.service;

import com.sphwms.arrival.internal.dto.requests.ArrivalRequest;
import com.sphwms.arrival.internal.dto.requests.QualityCheckRequest;
import com.sphwms.arrival.internal.dto.requests.RejectRequest;
import com.sphwms.arrival.internal.dto.responses.ArrivalResponse;
import com.sphwms.arrival.internal.dto.responses.ArrivalSummaryResponse;
import com.sphwms.arrival.internal.entity.Arrival;
import com.sphwms.arrival.internal.entity.QualityCheck;
import com.sphwms.arrival.internal.enums.ArrivalGrade;
import com.sphwms.arrival.internal.enums.ArrivalStatus;
import com.sphwms.arrival.internal.repository.ArrivalRepository;
import com.sphwms.arrival.internal.repository.QualityCheckRepository;
import com.sphwms.product.internal.entity.Product;
import com.sphwms.product.internal.repository.ProductRepository;
import com.sphwms.shared.audit.AuditService;
import com.sphwms.shared.exception.BusinessException;
import com.sphwms.shared.exception.NotFoundException;
import com.sphwms.shared.security.CurrentUserProvider;
import com.sphwms.shared.sequence.IdSequenceService;
import com.sphwms.stock.internal.entity.StockBatch;
import com.sphwms.stock.internal.entity.StockTransaction;
import com.sphwms.stock.internal.enums.StockTxnType;
import com.sphwms.stock.internal.repository.StockBatchRepository;
import com.sphwms.stock.internal.repository.StockTransactionRepository;
import com.sphwms.warehouse.internal.entity.Warehouse;
import com.sphwms.warehouse.internal.repository.WarehouseRepository;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ArrivalService: create (PENDING), confirm (quality check, capacity, stock batch),
 * reject and summary counts. All repositories are mocked, so no database is needed.
 * LENIENT strictness: remove the @MockitoSettings line to make Mockito also fail on unused stubs.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ArrivalServiceTest {

    private static Validator validator;

    @Mock private ArrivalRepository arrivalRepository;
    @Mock private QualityCheckRepository qualityCheckRepository;
    @Mock private ProductRepository productRepository;
    @Mock private WarehouseRepository warehouseRepository;
    @Mock private StockBatchRepository stockBatchRepository;
    @Mock private StockTransactionRepository stockTransactionRepository;
    @Mock private IdSequenceService idSequenceService;
    @Mock private CurrentUserProvider currentUserProvider;
    @Mock private AuditService auditService;
    @InjectMocks private ArrivalService service;

    @BeforeAll
    static void initValidator() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    @BeforeEach
    void commonStubs() {
        when(currentUserProvider.getCurrentUserId()).thenReturn(1L);
    }

    // ------------------------------------------------------------------ helpers

    private Product product(boolean active) {
        Product p = new Product();
        p.setProductId(1L);
        p.setName("Rice (Miniket)");
        p.setActive(active);
        p.setPurchasePrice(new BigDecimal("60"));
        p.setSellingPrice(new BigDecimal("70"));
        return p;
    }

    private Warehouse warehouse(boolean active, String capacity) {
        Warehouse w = new Warehouse();
        w.setWarehouseId(1L);
        w.setName("Warehouse A");
        w.setActive(active);
        w.setCapacityKg(new BigDecimal(capacity));
        return w;
    }

    private Arrival arrival(ArrivalStatus status, String qty) {
        Arrival a = new Arrival();
        a.setArrivalId(10L);
        a.setBatchNo("B-2026-101");
        a.setProductId(1L);
        a.setWarehouseId(1L);
        a.setQuantity(new BigDecimal(qty));
        a.setGrade(ArrivalGrade.A);
        a.setExpiryDate(LocalDate.now().plusDays(30));
        a.setPurchasePrice(new BigDecimal("60"));
        a.setTotalCost(new BigDecimal(qty).multiply(new BigDecimal("60")));
        a.setStatus(status);
        a.setCreatedBy(1L);
        return a;
    }

    private ArrivalRequest request(String qty, LocalDate expiry) {
        return new ArrivalRequest(1L, 1L, new BigDecimal(qty), ArrivalGrade.A, expiry, null);
    }

    private QualityCheckRequest allChecksOk() {
        return new QualityCheckRequest(true, true, true, true, true);
    }

    private static void assertBd(String expected, BigDecimal actual) {
        assertNotNull(actual);
        assertEquals(0, new BigDecimal(expected).compareTo(actual), "expected " + expected + " but was " + actual);
    }

    private void givenActiveProductAndWarehouse() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(true)));
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(warehouse(true, "1000")));
    }

    /** Everything createArrival needs to finish; returns a holder for the saved arrival. */
    private AtomicReference<Arrival> givenCreateWillSucceed() {
        givenActiveProductAndWarehouse();
        when(idSequenceService.nextBatchNo(any(LocalDate.class))).thenReturn("B-2026-101");
        AtomicReference<Arrival> holder = new AtomicReference<>();
        when(arrivalRepository.save(any(Arrival.class))).thenAnswer(inv -> {
            Arrival a = inv.getArgument(0);
            a.setArrivalId(10L);
            holder.set(a);
            return a;
        });
        when(arrivalRepository.findById(10L)).thenAnswer(inv -> Optional.of(holder.get()));
        return holder;
    }

    /** Stubs for a confirm that is expected to reach the end. usedKg = stock already in warehouse 1. */
    private void givenConfirmWillSucceed(Arrival a, String capacity, String usedKg) {
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(a));
        when(warehouseRepository.findByIdWithLock(1L)).thenReturn(Optional.of(warehouse(true, capacity)));
        List<Object[]> rows = Collections.singletonList(
                new Object[]{1L, new BigDecimal(usedKg), new BigDecimal("0")});
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(rows);
        when(arrivalRepository.save(any(Arrival.class))).thenAnswer(inv -> inv.getArgument(0));
        when(stockBatchRepository.save(any(StockBatch.class))).thenAnswer(inv -> {
            StockBatch b = inv.getArgument(0);
            b.setBatchId(55L);
            return b;
        });
        when(arrivalRepository.findById(10L)).thenReturn(Optional.of(a));
    }

    // ================================================================== CREATE ARRIVAL

    // ------------------------------------------------------------------ NORMAL

    @Test
    void createArrival_valid_isPendingWithServerCalculatedCostAndNoStockChange() {
        AtomicReference<Arrival> holder = givenCreateWillSucceed();

        // client sends purchasePrice = 1, it must be ignored: price is copied from the product (60)
        ArrivalRequest req = new ArrivalRequest(1L, 1L, new BigDecimal("500"), ArrivalGrade.A,
                LocalDate.now().plusDays(30), new BigDecimal("1"));
        ArrivalResponse res = service.createArrival(req);

        Arrival saved = holder.get();
        assertEquals(ArrivalStatus.PENDING, saved.getStatus());
        assertEquals("B-2026-101", saved.getBatchNo());
        assertBd("60", saved.getPurchasePrice());          // snapshot from product
        assertBd("30000", saved.getTotalCost());           // 500 x 60
        assertEquals(1L, saved.getCreatedBy());
        assertEquals(ArrivalStatus.PENDING, res.status());
        assertEquals("Rice (Miniket)", res.productName());
        // stock must not change until the quality check confirms the arrival
        verifyNoInteractions(stockBatchRepository, stockTransactionRepository);
        verify(auditService).log(eq("ARRIVAL_CREATE"), eq("ARRIVAL"), any(), anyString());
    }

    // ------------------------------------------------------------------ BOUNDARY

    @Test
    void createArrival_expiryTomorrow_isAccepted() {
        AtomicReference<Arrival> holder = givenCreateWillSucceed();

        service.createArrival(request("10", LocalDate.now().plusDays(1)));

        assertEquals(LocalDate.now().plusDays(1), holder.get().getExpiryDate());
    }

    @Test
    void createArrival_expiryToday_isRejected() {
        givenActiveProductAndWarehouse();

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createArrival(request("10", LocalDate.now())));

        assertEquals("Expiry date must be in the future.", ex.getMessage());
        verify(arrivalRepository, never()).save(any());
        verify(idSequenceService, never()).nextBatchNo(any());   // no batch number wasted
    }

    @Test
    void createArrival_expiryYesterday_isRejected() {
        givenActiveProductAndWarehouse();

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createArrival(request("10", LocalDate.now().minusDays(1))));

        assertEquals("Expiry date must be in the future.", ex.getMessage());
    }

    @Test
    void createArrival_missingExpiry_isRejected() {
        givenActiveProductAndWarehouse();

        assertThrows(BusinessException.class, () -> service.createArrival(request("10", null)));
        verify(arrivalRepository, never()).save(any());
    }

    // ------------------------------------------------------------------ INVALID INPUT

    @ParameterizedTest(name = "quantity {0} is rejected")
    @ValueSource(strings = {"0", "-1", "-0.01"})
    void createArrival_zeroOrNegativeQuantity_isRejected(String qty) {
        givenActiveProductAndWarehouse();

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createArrival(request(qty, LocalDate.now().plusDays(30))));

        assertEquals("Invalid quantity - enter a positive number.", ex.getMessage());
        verify(arrivalRepository, never()).save(any());
    }

    @Test
    void createArrival_nullQuantity_isRejected() {
        givenActiveProductAndWarehouse();
        ArrivalRequest req = new ArrivalRequest(1L, 1L, null, ArrivalGrade.A, LocalDate.now().plusDays(30), null);

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createArrival(req));

        assertEquals("Invalid quantity - enter a positive number.", ex.getMessage());
    }

    @Test
    void createArrival_inactiveWarehouse_isRejected() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(true)));
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(warehouse(false, "1000")));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createArrival(request("10", LocalDate.now().plusDays(30))));

        assertEquals("Cannot create arrival for inactive warehouse.", ex.getMessage());
        verify(arrivalRepository, never()).save(any());
    }

    @Test
    void createArrival_inactiveProduct_isRejected() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(false)));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createArrival(request("10", LocalDate.now().plusDays(30))));

        assertEquals("Cannot create arrival for inactive product.", ex.getMessage());
        verifyNoInteractions(warehouseRepository);
    }

    // ------------------------------------------------------------------ EXCEPTIONAL

    @Test
    void createArrival_unknownProduct_throws() {
        when(productRepository.findById(1L)).thenReturn(Optional.empty());

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createArrival(request("10", LocalDate.now().plusDays(30))));

        assertEquals("Product not found.", ex.getMessage());
    }

    @Test
    void createArrival_unknownWarehouse_throws() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(true)));
        when(warehouseRepository.findById(1L)).thenReturn(Optional.empty());

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createArrival(request("10", LocalDate.now().plusDays(30))));

        assertEquals("Warehouse not found.", ex.getMessage());
    }

    // ================================================================== CONFIRM ARRIVAL

    // ------------------------------------------------------------------ NORMAL

    @Test
    void confirmArrival_allChecksPass_confirmsAndCreatesStockBatchAndTransaction() {
        Arrival a = arrival(ArrivalStatus.PENDING, "500");
        givenConfirmWillSucceed(a, "1000", "200");

        ArrivalResponse res = service.confirmArrival(10L, allChecksOk());

        assertEquals(ArrivalStatus.CONFIRMED, a.getStatus());
        assertNotNull(a.getConfirmedAt());
        assertEquals(1L, a.getConfirmedBy());
        assertEquals(ArrivalStatus.CONFIRMED, res.status());

        ArgumentCaptor<StockBatch> batch = ArgumentCaptor.forClass(StockBatch.class);
        verify(stockBatchRepository).save(batch.capture());
        assertEquals(10L, batch.getValue().getArrivalId());
        assertBd("500", batch.getValue().getInitialQuantity());
        assertBd("500", batch.getValue().getRemainingQuantity());
        assertBd("60", batch.getValue().getUnitCost());     // cost snapshot from the arrival
        assertEquals(a.getExpiryDate(), batch.getValue().getExpiryDate());

        ArgumentCaptor<StockTransaction> txn = ArgumentCaptor.forClass(StockTransaction.class);
        verify(stockTransactionRepository).save(txn.capture());
        assertEquals(StockTxnType.ARRIVAL, txn.getValue().getTxnType());
        assertBd("500", txn.getValue().getQuantity());
        assertEquals(55L, txn.getValue().getBatchId());

        ArgumentCaptor<QualityCheck> qc = ArgumentCaptor.forClass(QualityCheck.class);
        verify(qualityCheckRepository).save(qc.capture());
        assertTrue(qc.getValue().getPackagingOk() && qc.getValue().getNoDamage()
                && qc.getValue().getQuantityMatch() && qc.getValue().getExpiryValid()
                && qc.getValue().getGradeMatch());
        verify(auditService).log(eq("ARRIVAL_CONFIRM"), eq("ARRIVAL"), any(), anyString());
    }

    // ------------------------------------------------------------------ BOUNDARY (capacity)

    @Test
    void confirmArrival_fillsWarehouseExactlyToCapacity_succeeds() {
        Arrival a = arrival(ArrivalStatus.PENDING, "500");
        givenConfirmWillSucceed(a, "1000", "500");           // 500 + 500 == 1000

        service.confirmArrival(10L, allChecksOk());

        assertEquals(ArrivalStatus.CONFIRMED, a.getStatus());
    }

    @Test
    void confirmArrival_exceedsCapacityByOnePaisa_isRejectedAndStockUntouched() {
        Arrival a = arrival(ArrivalStatus.PENDING, "500");
        givenConfirmWillSucceed(a, "1000", "500.01");        // 500.01 + 500 > 1000

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.confirmArrival(10L, allChecksOk()));

        assertEquals("Warehouse capacity exceeded.", ex.getMessage());
        assertEquals(ArrivalStatus.PENDING, a.getStatus());
        verify(stockBatchRepository, never()).save(any());
        verify(stockTransactionRepository, never()).save(any());
        verify(qualityCheckRepository, never()).save(any());
    }

    @Test
    void confirmArrival_warehouseWithNoStockRows_treatsUsedAsZero() {
        Arrival a = arrival(ArrivalStatus.PENDING, "1000");
        givenConfirmWillSucceed(a, "1000", "0");
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(Collections.emptyList());

        service.confirmArrival(10L, allChecksOk());

        assertEquals(ArrivalStatus.CONFIRMED, a.getStatus());
    }

    // ------------------------------------------------------------------ INVALID INPUT (quality check)

    /** Each of the 5 checkboxes must be ticked: untick them one by one. */
    @ParameterizedTest(name = "checkbox #{0} unticked -> cannot confirm")
    @ValueSource(ints = {0, 1, 2, 3, 4})
    void confirmArrival_anyOneCheckboxFalse_isRejected(int unticked) {
        boolean[] f = {true, true, true, true, true};
        f[unticked] = false;
        Arrival a = arrival(ArrivalStatus.PENDING, "500");
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(a));

        BusinessException ex = assertThrows(BusinessException.class, () ->
                service.confirmArrival(10L, new QualityCheckRequest(f[0], f[1], f[2], f[3], f[4])));

        assertEquals("Arrival data is invalid - cannot confirm.", ex.getMessage());
        assertEquals(ArrivalStatus.PENDING, a.getStatus());
        verifyNoInteractions(stockBatchRepository, stockTransactionRepository, qualityCheckRepository);
    }

    @Test
    void confirmArrival_checkboxMissing_countsAsNotChecked() {
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(arrival(ArrivalStatus.PENDING, "500")));

        assertThrows(BusinessException.class, () ->
                service.confirmArrival(10L, new QualityCheckRequest(true, null, true, true, true)));
        verifyNoInteractions(stockBatchRepository);
    }

    /**
     * KNOWN GAP found while writing tests: the controller accepts a confirm request with NO body
     * (@RequestBody(required = false)) and the service then skips the quality check completely.
     * Fix in ArrivalService.confirmArrival: if (qcReq == null) throw new BusinessException("Arrival data is invalid - cannot confirm.");
     * then delete the @Disabled line below.
     */
    @Test
    @Disabled("Known gap: confirm without a quality-check body currently succeeds. Apply the fix, then remove this line.")
    void confirmArrival_noQualityCheckBody_mustBeRejected() {
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(arrival(ArrivalStatus.PENDING, "500")));

        assertThrows(BusinessException.class, () -> service.confirmArrival(10L, null));
        verifyNoInteractions(stockBatchRepository);
    }

    // ------------------------------------------------------------------ EXCEPTIONAL

    @ParameterizedTest(name = "{0} arrival cannot be confirmed again")
    @EnumSource(value = ArrivalStatus.class, names = {"CONFIRMED", "REJECTED"})
    void confirmArrival_notPending_isRejectedAndStockDoesNotGrowTwice(ArrivalStatus status) {
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(arrival(status, "500")));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.confirmArrival(10L, allChecksOk()));

        assertEquals("Arrival already confirmed.", ex.getMessage());
        verifyNoInteractions(stockBatchRepository, stockTransactionRepository, qualityCheckRepository);
    }

    @Test
    void confirmArrival_unknownArrival_throwsNotFound() {
        when(arrivalRepository.findByIdWithLock(99L)).thenReturn(Optional.empty());

        NotFoundException ex = assertThrows(NotFoundException.class,
                () -> service.confirmArrival(99L, allChecksOk()));

        assertEquals("Arrival not found.", ex.getMessage());
    }

    @Test
    void confirmArrival_warehouseBecameInactive_isRejected() {
        Arrival a = arrival(ArrivalStatus.PENDING, "500");
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(a));
        when(warehouseRepository.findByIdWithLock(1L)).thenReturn(Optional.of(warehouse(false, "1000")));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.confirmArrival(10L, allChecksOk()));

        assertEquals("Cannot confirm arrival into inactive warehouse.", ex.getMessage());
        assertEquals(ArrivalStatus.PENDING, a.getStatus());
        verifyNoInteractions(stockBatchRepository);
    }

    @Test
    void confirmArrival_warehouseMissing_isRejected() {
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(arrival(ArrivalStatus.PENDING, "500")));
        when(warehouseRepository.findByIdWithLock(1L)).thenReturn(Optional.empty());

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.confirmArrival(10L, allChecksOk()));

        assertEquals("Warehouse not found.", ex.getMessage());
    }

    // ================================================================== REJECT ARRIVAL

    @Test
    void rejectArrival_withReason_rejectsTrimsReasonAndLeavesStockAlone() {
        Arrival a = arrival(ArrivalStatus.PENDING, "500");
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(a));
        when(arrivalRepository.save(any(Arrival.class))).thenAnswer(inv -> inv.getArgument(0));
        when(arrivalRepository.findById(10L)).thenReturn(Optional.of(a));

        ArrivalResponse res = service.rejectArrival(10L, new RejectRequest("  Damaged packaging  "));

        assertEquals(ArrivalStatus.REJECTED, a.getStatus());
        assertEquals("Damaged packaging", a.getRejectionReason());
        assertEquals(ArrivalStatus.REJECTED, res.status());
        ArgumentCaptor<QualityCheck> qc = ArgumentCaptor.forClass(QualityCheck.class);
        verify(qualityCheckRepository).save(qc.capture());
        assertFalse(qc.getValue().getPackagingOk());          // a rejected check records the failure
        verifyNoInteractions(stockBatchRepository, stockTransactionRepository);
        verify(auditService).log(eq("ARRIVAL_REJECT"), eq("ARRIVAL"), any(), anyString());
    }

    @ParameterizedTest(name = "reason \"{0}\" is not accepted")
    @ValueSource(strings = {"", " ", "      "})
    void rejectArrival_blankReason_isRejected(String reason) {
        Arrival a = arrival(ArrivalStatus.PENDING, "500");
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(a));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.rejectArrival(10L, new RejectRequest(reason)));

        assertEquals("Rejection reason is required.", ex.getMessage());
        assertEquals(ArrivalStatus.PENDING, a.getStatus());
        verify(qualityCheckRepository, never()).save(any());
    }

    @Test
    void rejectArrival_nullBodyOrNullReason_isRejected() {
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(arrival(ArrivalStatus.PENDING, "500")));

        assertEquals("Rejection reason is required.",
                assertThrows(BusinessException.class, () -> service.rejectArrival(10L, null)).getMessage());
        assertEquals("Rejection reason is required.",
                assertThrows(BusinessException.class, () -> service.rejectArrival(10L, new RejectRequest(null))).getMessage());
    }

    @ParameterizedTest(name = "{0} arrival cannot be rejected")
    @EnumSource(value = ArrivalStatus.class, names = {"CONFIRMED", "REJECTED"})
    void rejectArrival_notPending_isRejected(ArrivalStatus status) {
        when(arrivalRepository.findByIdWithLock(10L)).thenReturn(Optional.of(arrival(status, "500")));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.rejectArrival(10L, new RejectRequest("Bad quality")));

        assertEquals("Arrival cannot be rejected.", ex.getMessage());
        verify(qualityCheckRepository, never()).save(any());
    }

    @Test
    void rejectArrival_unknownArrival_throwsNotFound() {
        when(arrivalRepository.findByIdWithLock(99L)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> service.rejectArrival(99L, new RejectRequest("x")));
    }

    // ================================================================== SUMMARY

    @Test
    void getSummary_totalIsSumOfThreeStatuses() {
        when(arrivalRepository.countByStatus(ArrivalStatus.PENDING)).thenReturn(2L);
        when(arrivalRepository.countByStatus(ArrivalStatus.CONFIRMED)).thenReturn(5L);
        when(arrivalRepository.countByStatus(ArrivalStatus.REJECTED)).thenReturn(1L);

        ArrivalSummaryResponse s = service.getSummary();

        assertEquals(new ArrivalSummaryResponse(8, 2, 5, 1), s);
    }

    @Test
    void getSummary_noArrivals_allZero() {
        ArrivalSummaryResponse s = service.getSummary();   // mocks return 0 for long

        assertEquals(new ArrivalSummaryResponse(0, 0, 0, 0), s);
    }

    // ================================================================== INVALID INPUT (bean validation on the request)

    private static Set<String> messages(Set<ConstraintViolation<ArrivalRequest>> violations) {
        return violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toSet());
    }

    @Test
    void arrivalRequest_validRequest_hasNoViolations() {
        assertTrue(validator.validate(request("10", LocalDate.now().plusDays(1))).isEmpty());
    }

    @Test
    void arrivalRequest_expiryToday_failsFutureRule() {
        assertEquals(Set.of("Expiry date must be in the future."),
                messages(validator.validate(request("10", LocalDate.now()))));
    }

    @ParameterizedTest(name = "quantity {0} fails validation")
    @ValueSource(strings = {"0", "-5"})
    void arrivalRequest_nonPositiveQuantity_fails(String qty) {
        assertEquals(Set.of("Invalid quantity - enter a positive number."),
                messages(validator.validate(request(qty, LocalDate.now().plusDays(1)))));
    }

    @Test
    void arrivalRequest_allRequiredFieldsMissing_reportsRequiredMessage() {
        ArrivalRequest empty = new ArrivalRequest(null, null, null, null, null, null);

        Set<String> msgs = messages(validator.validate(empty));

        assertTrue(msgs.contains("Required fields are missing."));
        assertTrue(msgs.contains("Invalid quantity - enter a positive number."));
    }
}
