package com.sphwms.auth.internal.service;

import com.sphwms.auth.internal.dto.requests.LoginRequest;
import com.sphwms.auth.internal.dto.responses.LoginResponse;
import com.sphwms.auth.internal.dto.responses.LoginResponse.UserInfo;
import com.sphwms.user.internal.entity.AppUser;
import com.sphwms.user.internal.repository.AppUserRepository;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for AuthService.login / me.
 * Repository, password encoder and JWT service are mocked, so no database is needed.
 * LENIENT strictness: remove the @MockitoSettings line to make Mockito also fail on unused stubs.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class AuthServiceTest {

    private static final String LOCKED_MSG =
            "Account locked after 5 failed attempts. Please contact the administrator.";

    private static Validator validator;

    @Mock private AppUserRepository users;
    @Mock private PasswordEncoder passwordEncoder;
    @Mock private JwtService jwtService;
    @InjectMocks private AuthService authService;

    @BeforeAll
    static void initValidator() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    @BeforeEach
    void setUp() {
        // expirationMs is a @Value field, so set it by hand (30 minutes)
        ReflectionTestUtils.setField(authService, "expirationMs", 1_800_000L);
    }

    private AppUser user(String status, int failedAttempts) {
        AppUser u = new AppUser();
        u.setUserId(1L);
        u.setUsername("manager");
        u.setPasswordHash("hash");
        u.setFullName("Rahim Uddin");
        u.setRole("MANAGER");
        u.setStatus(status);
        u.setFailedAttempts(failedAttempts);
        return u;
    }

    // ------------------------------------------------------------------ NORMAL

    @Test
    void login_validCredentials_returnsTokenAndResetsFailedAttempts() {
        AppUser u = user("ACTIVE", 3);
        when(users.findByUsername("manager")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("Manager@123", "hash")).thenReturn(true);
        when(jwtService.generate("manager", "MANAGER")).thenReturn("jwt-token");

        LoginResponse res = authService.login(new LoginRequest("manager", "Manager@123"));

        assertEquals("jwt-token", res.token());
        assertEquals(1800L, res.expiresInSeconds());
        assertEquals("manager", res.user().username());
        assertEquals("MANAGER", res.user().role());
        assertEquals(0, u.getFailedAttempts());
        assertNotNull(u.getLastLogin());
        verify(users).save(u);
    }

    @Test
    void login_roleWithSpaces_isNormalizedToUpperSnakeCase() {
        AppUser u = user("ACTIVE", 0);
        u.setRole("Warehouse Manager");
        when(users.findByUsername("manager")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("Manager@123", "hash")).thenReturn(true);
        when(jwtService.generate("manager", "WAREHOUSE_MANAGER")).thenReturn("jwt-token");

        LoginResponse res = authService.login(new LoginRequest("manager", "Manager@123"));

        assertEquals("WAREHOUSE_MANAGER", res.user().role());
        verify(jwtService).generate("manager", "WAREHOUSE_MANAGER");
    }

    @Test
    void login_usernameWithSurroundingSpaces_isTrimmed() {
        AppUser u = user("ACTIVE", 0);
        when(users.findByUsername("manager")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("Manager@123", "hash")).thenReturn(true);
        when(jwtService.generate("manager", "MANAGER")).thenReturn("jwt-token");

        LoginResponse res = authService.login(new LoginRequest("  manager  ", "Manager@123"));

        assertEquals("jwt-token", res.token());
    }

    // ------------------------------------------------------------------ BOUNDARY

    /** before = failed attempts already stored, after = expected after one more wrong password. */
    @ParameterizedTest(name = "wrong password with {0} earlier failures -> attempts {1}, status {2}")
    @CsvSource({"0,1,ACTIVE", "3,4,ACTIVE", "4,5,LOCKED"})
    void login_wrongPassword_countsAttemptsAndLocksOnFifth(int before, int after, String expectedStatus) {
        AppUser u = user("ACTIVE", before);
        when(users.findByUsername("manager")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("wrong", "hash")).thenReturn(false);

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> authService.login(new LoginRequest("manager", "wrong")));

        assertEquals(401, ex.getStatusCode().value());
        assertEquals("Invalid username or password.", ex.getReason());
        assertEquals(after, u.getFailedAttempts());
        assertEquals(expectedStatus, u.getStatus());
        verify(users).save(u);
        verifyNoInteractions(jwtService);
    }

    @Test
    void login_statusInLowerCase_stillTreatedAsActive() {
        AppUser u = user("active", 0);
        when(users.findByUsername("manager")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("Manager@123", "hash")).thenReturn(true);
        when(jwtService.generate("manager", "MANAGER")).thenReturn("jwt-token");

        assertEquals("jwt-token", authService.login(new LoginRequest("manager", "Manager@123")).token());
    }

    // ------------------------------------------------------------------ INVALID INPUT

    @Test
    void login_unknownUser_returnsSameGenericMessageAsWrongPassword() {
        when(users.findByUsername("ghost")).thenReturn(Optional.empty());

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> authService.login(new LoginRequest("ghost", "whatever")));

        assertEquals(401, ex.getStatusCode().value());
        // must not reveal whether the username or the password was wrong
        assertEquals("Invalid username or password.", ex.getReason());
        verifyNoInteractions(passwordEncoder, jwtService);
        verify(users, never()).save(any());
    }

    @Test
    void loginRequest_blankUsernameAndPassword_failsBeanValidation() {
        Set<String> messages = messages(validator.validate(new LoginRequest("  ", "")));

        assertEquals(Set.of("Username is required.", "Password is required."), messages);
    }

    @Test
    void loginRequest_nullFields_failsBeanValidation() {
        assertEquals(2, validator.validate(new LoginRequest(null, null)).size());
    }

    @Test
    void loginRequest_validFields_hasNoViolations() {
        assertTrue(validator.validate(new LoginRequest("manager", "Manager@123")).isEmpty());
    }

    // ------------------------------------------------------------------ EXCEPTIONAL

    @ParameterizedTest(name = "status {0} cannot log in")
    @ValueSource(strings = {"LOCKED", "BLOCKED", "INACTIVE"})
    void login_nonActiveAccount_isRejectedEvenWithCorrectPassword(String status) {
        AppUser u = user(status, 5);
        when(users.findByUsername("manager")).thenReturn(Optional.of(u));
        when(passwordEncoder.matches("Manager@123", "hash")).thenReturn(true);

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> authService.login(new LoginRequest("manager", "Manager@123")));

        assertEquals(403, ex.getStatusCode().value());
        assertEquals(LOCKED_MSG, ex.getReason());
        // password is not even checked and no token is issued
        verify(passwordEncoder, never()).matches(any(), any());
        verifyNoInteractions(jwtService);
        verify(users, never()).save(any());
    }

    @Test
    void me_existingUser_returnsInfoWithEmptyStringsForMissingEmailAndPhone() {
        AppUser u = user("ACTIVE", 0);
        u.setEmail(null);
        u.setPhone(null);
        when(users.findByUsername("manager")).thenReturn(Optional.of(u));

        UserInfo info = authService.me("manager");

        assertEquals("Rahim Uddin", info.fullName());
        assertEquals("MANAGER", info.role());
        assertEquals("", info.email());
        assertEquals("", info.phone());
    }

    @Test
    void me_unknownUser_throwsUnauthorized() {
        when(users.findByUsername("ghost")).thenReturn(Optional.empty());

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> authService.me("ghost"));

        assertEquals(401, ex.getStatusCode().value());
    }

    private static Set<String> messages(Set<? extends ConstraintViolation<?>> violations) {
        return violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toSet());
    }
}
