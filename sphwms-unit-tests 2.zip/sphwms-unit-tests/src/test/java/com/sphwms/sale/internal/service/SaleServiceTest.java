package com.sphwms.sale.internal.service;

import com.sphwms.buyer.internal.entity.Buyer;
import com.sphwms.buyer.internal.enums.BuyerStatus;
import com.sphwms.buyer.internal.repository.BuyerRepository;
import com.sphwms.product.internal.entity.Product;
import com.sphwms.product.internal.repository.ProductRepository;
import com.sphwms.sale.internal.dto.requests.SaleRequest;
import com.sphwms.sale.internal.dto.responses.SaleResponse;
import com.sphwms.sale.internal.entity.Sale;
import com.sphwms.sale.internal.entity.SaleAllocation;
import com.sphwms.sale.internal.enums.PaymentStatus;
import com.sphwms.sale.internal.enums.SaleStatus;
import com.sphwms.sale.internal.repository.SaleAllocationRepository;
import com.sphwms.sale.internal.repository.SaleRepository;
import com.sphwms.shared.audit.AuditService;
import com.sphwms.shared.exception.BusinessException;
import com.sphwms.shared.exception.NotFoundException;
import com.sphwms.shared.security.CurrentUserProvider;
import com.sphwms.shared.sequence.IdSequenceService;
import com.sphwms.stock.internal.entity.StockBatch;
import com.sphwms.stock.internal.entity.StockTransaction;
import com.sphwms.stock.internal.enums.StockTxnType;
import com.sphwms.stock.internal.repository.StockBatchRepository;
import com.sphwms.stock.internal.repository.StockTransactionRepository;
import com.sphwms.warehouse.internal.entity.Warehouse;
import com.sphwms.warehouse.internal.repository.WarehouseRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * Unit tests for SaleService (create sale, FIFO stock allocation, cancel, history filter).
 * Product price is 70/kg (cost 60/kg) in every test. All repositories are mocked, no database needed.
 * LENIENT strictness: remove the @MockitoSettings line to make Mockito also fail on unused stubs.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class SaleServiceTest {

    @Mock private SaleRepository saleRepository;
    @Mock private SaleAllocationRepository saleAllocationRepository;
    @Mock private BuyerRepository buyerRepository;
    @Mock private ProductRepository productRepository;
    @Mock private WarehouseRepository warehouseRepository;
    @Mock private StockBatchRepository stockBatchRepository;
    @Mock private StockTransactionRepository stockTransactionRepository;
    @Mock private IdSequenceService idSequenceService;
    @Mock private CurrentUserProvider currentUserProvider;
    @Mock private AuditService auditService;
    @InjectMocks private SaleService service;

    private final LocalDate today = LocalDate.now();

    @BeforeEach
    void commonStubs() {
        when(currentUserProvider.getCurrentUserId()).thenReturn(1L);
        when(idSequenceService.nextSaleNo()).thenReturn("S-0001");
        when(saleRepository.save(any(Sale.class))).thenAnswer(inv -> {
            Sale s = inv.getArgument(0);
            s.setSaleId(100L);
            return s;
        });
    }

    // ------------------------------------------------------------------ helpers

    private Buyer buyer(BuyerStatus status) {
        Buyer b = new Buyer();
        b.setBuyerId(1L);
        b.setName("Karim Store");
        b.setStatus(status);
        return b;
    }

    private Product product(boolean active) {
        Product p = new Product();
        p.setProductId(1L);
        p.setName("Rice (Miniket)");
        p.setActive(active);
        p.setSellingPrice(new BigDecimal("70"));
        p.setPurchasePrice(new BigDecimal("60"));
        return p;
    }

    private Warehouse warehouse(boolean active) {
        Warehouse w = new Warehouse();
        w.setWarehouseId(1L);
        w.setName("Warehouse A");
        w.setActive(active);
        return w;
    }

    private StockBatch batch(long id, String remaining, int daysToExpiry) {
        StockBatch b = new StockBatch();
        b.setBatchId(id);
        b.setProductId(1L);
        b.setWarehouseId(1L);
        b.setRemainingQuantity(new BigDecimal(remaining));
        b.setExpiryDate(today.plusDays(daysToExpiry));
        return b;
    }

    private SaleRequest request(String qty, String paidNow, LocalDate saleDate) {
        return new SaleRequest(1L, 1L, 1L, new BigDecimal(qty), null, null,
                paidNow == null ? null : new BigDecimal(paidNow), saleDate, null);
    }

    private SaleRequest request(String qty, String paidNow) {
        return request(qty, paidNow, today);
    }

    private void givenActiveBuyerProductWarehouse() {
        when(buyerRepository.findById(1L)).thenReturn(Optional.of(buyer(BuyerStatus.ACTIVE)));
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(true)));
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(warehouse(true)));
    }

    /** The repository query already returns batches ordered by expiry date (earliest first). */
    private void givenBatches(StockBatch... batches) {
        when(stockBatchRepository.findAvailableBatchesForSaleWithLock(eq(1L), eq(1L), any(LocalDate.class)))
                .thenReturn(Arrays.asList(batches));
    }

    private Sale savedSale() {
        ArgumentCaptor<Sale> captor = ArgumentCaptor.forClass(Sale.class);
        verify(saleRepository).save(captor.capture());
        return captor.getValue();
    }

    private static void assertBd(String expected, BigDecimal actual) {
        assertNotNull(actual);
        assertEquals(0, new BigDecimal(expected).compareTo(actual), "expected " + expected + " but was " + actual);
    }

    private void verifyNothingSaved() {
        verify(saleRepository, never()).save(any());
        verifyNoInteractions(saleAllocationRepository, stockTransactionRepository, auditService);
        verify(stockBatchRepository, never()).save(any());
    }

    // ================================================================== CREATE SALE

    // ------------------------------------------------------------------ NORMAL

    @Test
    void createSale_fullPayment_isPaidAndStockIsReduced() {
        givenActiveBuyerProductWarehouse();
        StockBatch b = batch(1L, "500", 30);
        givenBatches(b);

        SaleResponse res = service.createSale(request("100", "7000"));      // 100 kg x Tk 70

        assertEquals(PaymentStatus.PAID, res.paymentStatus());
        assertBd("7000", res.totalAmount());
        assertBd("7000", res.paidAmount());
        assertBd("0", res.dueAmount());
        assertBd("400", b.getRemainingQuantity());                          // 500 - 100

        Sale sale = savedSale();
        assertEquals("S-0001", sale.getSaleNo());
        assertEquals(SaleStatus.CONFIRMED, sale.getStatus());
        assertBd("70", sale.getRate());
        assertBd("60", sale.getPurchasePrice());                            // cost snapshot for profit reports
        assertNull(sale.getDueDate());                                      // fully paid: no due date
        verify(auditService).log(eq("SALE_CREATE"), eq("SALE"), any(), anyString());
    }

    @Test
    void createSale_partialPayment_isDueWithDefaultDueDateAfter15Days() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));

        SaleResponse res = service.createSale(request("100", "3000"));

        assertEquals(PaymentStatus.DUE, res.paymentStatus());
        assertBd("3000", res.paidAmount());
        assertBd("4000", res.dueAmount());                                  // 7000 - 3000
        assertEquals(today.plusDays(15), savedSale().getDueDate());
    }

    @Test
    void createSale_noPaymentGiven_isDueForTheWholeAmount() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));

        SaleResponse res = service.createSale(request("100", null));

        assertEquals(PaymentStatus.DUE, res.paymentStatus());
        assertBd("0", res.paidAmount());
        assertBd("7000", res.dueAmount());
    }

    @Test
    void createSale_paidAmountFieldUsedWhenPaidNowIsMissing() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));
        SaleRequest req = new SaleRequest(1L, 1L, 1L, new BigDecimal("100"), null,
                new BigDecimal("7000"), null, today, null);

        assertEquals(PaymentStatus.PAID, service.createSale(req).paymentStatus());
    }

    @Test
    void createSale_clientSentRateIsIgnored_priceComesFromProduct() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));
        SaleRequest req = new SaleRequest(1L, 1L, 1L, new BigDecimal("100"), new BigDecimal("1"),
                null, new BigDecimal("7000"), today, null);

        SaleResponse res = service.createSale(req);

        assertBd("70", res.rate());
        assertBd("7000", res.totalAmount());
    }

    @Test
    void createSale_oldSaleDate_dueDateCountsFromSaleDate() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));

        service.createSale(request("100", "0", today.minusDays(3)));

        assertEquals(today.plusDays(12), savedSale().getDueDate());          // (today - 3) + 15
    }

    @Test
    void createSale_quantitySpansTwoBatches_takesEarliestExpiryFirstAndSavesAllocations() {
        givenActiveBuyerProductWarehouse();
        StockBatch early = batch(1L, "60", 5);
        StockBatch late = batch(2L, "100", 20);
        givenBatches(early, late);                                           // repository returns expiry order

        service.createSale(request("100", "0"));

        assertBd("0", early.getRemainingQuantity());                         // fully used first
        assertBd("60", late.getRemainingQuantity());                         // 100 - 40

        ArgumentCaptor<SaleAllocation> alloc = ArgumentCaptor.forClass(SaleAllocation.class);
        verify(saleAllocationRepository, times(2)).save(alloc.capture());
        List<SaleAllocation> allocations = alloc.getAllValues();
        assertEquals(1L, allocations.get(0).getBatchId());
        assertBd("60", allocations.get(0).getQuantity());
        assertEquals(2L, allocations.get(1).getBatchId());
        assertBd("40", allocations.get(1).getQuantity());
        assertEquals(100L, allocations.get(0).getSaleId());

        ArgumentCaptor<StockTransaction> txn = ArgumentCaptor.forClass(StockTransaction.class);
        verify(stockTransactionRepository, times(2)).save(txn.capture());
        assertTrue(txn.getAllValues().stream().allMatch(t -> t.getTxnType() == StockTxnType.SALE));
        assertBd("100", txn.getAllValues().stream().map(StockTransaction::getQuantity)
                .reduce(BigDecimal.ZERO, BigDecimal::add));                 // 60 + 40 = quantity sold
    }

    @Test
    void createSale_quantityFitsInFirstBatch_secondBatchIsUntouched() {
        givenActiveBuyerProductWarehouse();
        StockBatch early = batch(1L, "60", 5);
        StockBatch late = batch(2L, "100", 20);
        givenBatches(early, late);

        service.createSale(request("50", "0"));

        assertBd("10", early.getRemainingQuantity());
        assertBd("100", late.getRemainingQuantity());
        verify(saleAllocationRepository, times(1)).save(any(SaleAllocation.class));
    }

    // ------------------------------------------------------------------ BOUNDARY

    @Test
    void createSale_paidExactlyTotal_isPaid() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));

        assertEquals(PaymentStatus.PAID, service.createSale(request("100", "7000")).paymentStatus());
    }

    @Test
    void createSale_paidOnePaisaAboveTotal_isRejected() {
        givenActiveBuyerProductWarehouse();

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("100", "7000.01")));

        assertEquals("Paid amount cannot be more than the total.", ex.getMessage());
        verifyNothingSaved();
        verify(stockBatchRepository, never()).findAvailableBatchesForSaleWithLock(any(), any(), any());
    }

    @Test
    void createSale_paidOnePaisaBelowTotal_isStillDue() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));

        SaleResponse res = service.createSale(request("100", "6999.99"));

        assertEquals(PaymentStatus.DUE, res.paymentStatus());
        assertBd("0.01", res.dueAmount());
    }

    @Test
    void createSale_quantityEqualsAllStock_succeedsAndLeavesZero() {
        givenActiveBuyerProductWarehouse();
        StockBatch early = batch(1L, "60", 5);
        StockBatch late = batch(2L, "100", 20);
        givenBatches(early, late);

        service.createSale(request("160", "0"));                             // 60 + 100

        assertBd("0", early.getRemainingQuantity());
        assertBd("0", late.getRemainingQuantity());
    }

    @Test
    void createSale_quantityOnePaisaMoreThanStock_isRejectedWithNoSideEffects() {
        givenActiveBuyerProductWarehouse();
        StockBatch early = batch(1L, "60", 5);
        StockBatch late = batch(2L, "100", 20);
        givenBatches(early, late);

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("160.01", "0")));

        assertEquals("Insufficient stock for this sale.", ex.getMessage());
        assertBd("60", early.getRemainingQuantity());                        // nothing was taken
        assertBd("100", late.getRemainingQuantity());
        verifyNothingSaved();
    }

    @Test
    void createSale_saleDateToday_isAllowedAndTomorrowIsNot() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));

        assertDoesNotThrow(() -> service.createSale(request("1", "70", today)));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("1", "70", today.plusDays(1))));
        assertEquals("Sale date cannot be in the future.", ex.getMessage());
    }

    // ------------------------------------------------------------------ INVALID INPUT

    @ParameterizedTest(name = "quantity {0} is rejected")
    @ValueSource(strings = {"0", "-1", "-0.01"})
    void createSale_zeroOrNegativeQuantity_isRejectedBeforeAnyLookup(String qty) {
        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request(qty, "0")));

        assertEquals("Invalid quantity - enter a positive number.", ex.getMessage());
        verifyNoInteractions(buyerRepository, productRepository, warehouseRepository, stockBatchRepository);
        verifyNothingSaved();
    }

    @Test
    void createSale_nullQuantity_isRejected() {
        SaleRequest req = new SaleRequest(1L, 1L, 1L, null, null, null, null, today, null);

        BusinessException ex = assertThrows(BusinessException.class, () -> service.createSale(req));

        assertEquals("Invalid quantity - enter a positive number.", ex.getMessage());
    }

    @Test
    void createSale_inactiveBuyer_isRejected() {
        when(buyerRepository.findById(1L)).thenReturn(Optional.of(buyer(BuyerStatus.INACTIVE)));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("10", "0")));

        assertEquals("Cannot create sale for inactive buyer.", ex.getMessage());
        verifyNothingSaved();
    }

    @Test
    void createSale_inactiveProduct_isRejected() {
        when(buyerRepository.findById(1L)).thenReturn(Optional.of(buyer(BuyerStatus.ACTIVE)));
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(false)));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("10", "0")));

        assertEquals("Cannot create sale for inactive product.", ex.getMessage());
        verifyNothingSaved();
    }

    @Test
    void createSale_inactiveWarehouse_isRejected() {
        when(buyerRepository.findById(1L)).thenReturn(Optional.of(buyer(BuyerStatus.ACTIVE)));
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(true)));
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(warehouse(false)));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("10", "0")));

        assertEquals("Cannot create sale for inactive warehouse.", ex.getMessage());
        verifyNothingSaved();
    }

    /**
     * KNOWN GAP found while writing tests: a negative "paidNow" is accepted today (no check in the
     * DTO or the service), so the sale is saved with a negative paid amount.
     * Fix in SaleService.createSale, just before the "paid > total" check:
     *   if (paid.compareTo(BigDecimal.ZERO) < 0) throw new BusinessException("Paid amount cannot be negative.");
     * then delete the @Disabled line below.
     */
    @Test
    @Disabled("Known gap: negative paidNow is currently accepted. Apply the fix, then remove this line.")
    void createSale_negativePaidNow_mustBeRejected() {
        givenActiveBuyerProductWarehouse();
        givenBatches(batch(1L, "500", 30));

        assertThrows(BusinessException.class, () -> service.createSale(request("100", "-1")));
        verifyNothingSaved();
    }

    // ------------------------------------------------------------------ EXCEPTIONAL

    @Test
    void createSale_unknownBuyer_throws() {
        when(buyerRepository.findById(1L)).thenReturn(Optional.empty());

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("10", "0")));

        assertEquals("Buyer not found.", ex.getMessage());
        verifyNothingSaved();
    }

    @Test
    void createSale_unknownProduct_throws() {
        when(buyerRepository.findById(1L)).thenReturn(Optional.of(buyer(BuyerStatus.ACTIVE)));
        when(productRepository.findById(1L)).thenReturn(Optional.empty());

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("10", "0")));

        assertEquals("Product not found.", ex.getMessage());
    }

    @Test
    void createSale_unknownWarehouse_throws() {
        when(buyerRepository.findById(1L)).thenReturn(Optional.of(buyer(BuyerStatus.ACTIVE)));
        when(productRepository.findById(1L)).thenReturn(Optional.of(product(true)));
        when(warehouseRepository.findById(1L)).thenReturn(Optional.empty());

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("10", "0")));

        assertEquals("Warehouse not found.", ex.getMessage());
    }

    @Test
    void createSale_noSellableBatches_isInsufficientStock() {
        // e.g. everything in this warehouse is expired or used up: the query returns nothing
        givenActiveBuyerProductWarehouse();
        givenBatches();

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createSale(request("1", "0")));

        assertEquals("Insufficient stock for this sale.", ex.getMessage());
        verifyNothingSaved();
    }

    // ================================================================== CANCEL SALE

    private Sale confirmedSale() {
        Sale s = new Sale();
        s.setSaleId(100L);
        s.setSaleNo("S-0001");
        s.setBuyerId(1L);
        s.setProductId(1L);
        s.setQuantity(new BigDecimal("100"));
        s.setRate(new BigDecimal("70"));
        s.setPurchasePrice(new BigDecimal("60"));
        s.setTotalAmount(new BigDecimal("7000"));
        s.setPaidAmount(new BigDecimal("7000"));
        s.setPaymentStatus(PaymentStatus.PAID);
        s.setStatus(SaleStatus.CONFIRMED);
        s.setSaleDate(today);
        return s;
    }

    private SaleAllocation allocation(long batchId, String qty) {
        SaleAllocation a = new SaleAllocation();
        a.setSaleId(100L);
        a.setBatchId(batchId);
        a.setWarehouseId(1L);
        a.setQuantity(new BigDecimal(qty));
        return a;
    }

    @Test
    void cancelSale_returnsStockToEveryBatchItCameFrom() {
        Sale sale = confirmedSale();
        StockBatch b1 = batch(1L, "0", 5);
        StockBatch b2 = batch(2L, "60", 20);
        when(saleRepository.findByIdWithLock(100L)).thenReturn(Optional.of(sale));
        when(saleAllocationRepository.findBySaleId(100L))
                .thenReturn(Arrays.asList(allocation(1L, "60"), allocation(2L, "40")));
        when(stockBatchRepository.findByIdWithLock(1L)).thenReturn(Optional.of(b1));
        when(stockBatchRepository.findByIdWithLock(2L)).thenReturn(Optional.of(b2));

        SaleResponse res = service.cancelSale(100L, "  Wrong buyer ");

        assertEquals(SaleStatus.CANCELLED, sale.getStatus());
        assertEquals("Wrong buyer", sale.getCancelReason());                 // trimmed
        assertEquals(SaleStatus.CANCELLED, res.status());
        assertBd("60", b1.getRemainingQuantity());                           // 0 + 60
        assertBd("100", b2.getRemainingQuantity());                          // 60 + 40

        ArgumentCaptor<StockTransaction> txn = ArgumentCaptor.forClass(StockTransaction.class);
        verify(stockTransactionRepository, times(2)).save(txn.capture());
        assertTrue(txn.getAllValues().stream().allMatch(t -> t.getTxnType() == StockTxnType.SALE_CANCEL));
        verify(auditService).log(eq("SALE_CANCEL"), eq("SALE"), any(), anyString());
    }

    @Test
    void cancelSale_nullReason_usesDefaultText() {
        Sale sale = confirmedSale();
        when(saleRepository.findByIdWithLock(100L)).thenReturn(Optional.of(sale));
        when(saleAllocationRepository.findBySaleId(100L)).thenReturn(List.of());

        service.cancelSale(100L, null);

        assertEquals("Cancelled by manager", sale.getCancelReason());
    }

    @Test
    void cancelSale_batchNoLongerExists_isSkippedButSaleIsStillCancelled() {
        Sale sale = confirmedSale();
        when(saleRepository.findByIdWithLock(100L)).thenReturn(Optional.of(sale));
        when(saleAllocationRepository.findBySaleId(100L)).thenReturn(List.of(allocation(9L, "100")));
        when(stockBatchRepository.findByIdWithLock(9L)).thenReturn(Optional.empty());

        service.cancelSale(100L, "x");

        assertEquals(SaleStatus.CANCELLED, sale.getStatus());
        verify(stockTransactionRepository, never()).save(any());
    }

    @Test
    void cancelSale_alreadyCancelled_isRejectedAndStockIsNotReturnedTwice() {
        Sale sale = confirmedSale();
        sale.setStatus(SaleStatus.CANCELLED);
        when(saleRepository.findByIdWithLock(100L)).thenReturn(Optional.of(sale));

        BusinessException ex = assertThrows(BusinessException.class, () -> service.cancelSale(100L, "again"));

        assertEquals("Sale is already cancelled.", ex.getMessage());
        verifyNoInteractions(saleAllocationRepository, stockTransactionRepository);
        verify(stockBatchRepository, never()).save(any());
    }

    @Test
    void cancelSale_unknownSale_throwsNotFound() {
        when(saleRepository.findByIdWithLock(99L)).thenReturn(Optional.empty());

        NotFoundException ex = assertThrows(NotFoundException.class, () -> service.cancelSale(99L, "x"));

        assertEquals("Sale not found.", ex.getMessage());
    }

    // ================================================================== PURCHASE HISTORY (date filter)

    private Sale saleOn(long id, LocalDate date) {
        Sale s = confirmedSale();
        s.setSaleId(id);
        s.setSaleNo("S-000" + id);
        s.setSaleDate(date);
        return s;
    }

    @Test
    void getAllSales_dateRangeIsInclusiveOnBothEnds() {
        when(saleRepository.findAllByOrderBySaleIdDesc()).thenReturn(Arrays.asList(
                saleOn(4, today), saleOn(3, today.minusDays(1)), saleOn(2, today.minusDays(2)), saleOn(1, today.minusDays(3))));

        List<String> numbers = service.getAllSales(null, today.minusDays(2), today.minusDays(1)).stream()
                .map(SaleResponse::saleNo).collect(Collectors.toList());

        assertEquals(List.of("S-0003", "S-0002"), numbers);
    }

    @Test
    void getAllSales_fromEqualsTo_returnsThatSingleDay() {
        when(saleRepository.findAllByOrderBySaleIdDesc()).thenReturn(Arrays.asList(
                saleOn(2, today), saleOn(1, today.minusDays(1))));

        assertEquals(1, service.getAllSales(null, today, today).size());
    }

    @Test
    void getAllSales_fromAfterTo_isRejected() {
        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.getAllSales(null, today, today.minusDays(1)));

        assertEquals("Invalid date range.", ex.getMessage());
        verifyNoInteractions(saleRepository);
    }

    @Test
    void getAllSales_withBuyerId_usesBuyerQueryAndDueIsNeverNegative() {
        Sale s = saleOn(1, today);
        s.setPaidAmount(new BigDecimal("8000"));                             // overpaid on paper
        when(saleRepository.findByBuyerIdOrderBySaleIdDesc(1L)).thenReturn(List.of(s));

        List<SaleResponse> list = service.getAllSales(1L, null, null);

        assertEquals(1, list.size());
        assertBd("0", list.get(0).dueAmount());
        verify(saleRepository, never()).findAllByOrderBySaleIdDesc();
    }

    @Test
    void getAllSales_noSales_returnsEmptyList() {
        when(saleRepository.findAllByOrderBySaleIdDesc()).thenReturn(List.of());

        assertTrue(service.getAllSales(null, null, null).isEmpty());
    }
}
