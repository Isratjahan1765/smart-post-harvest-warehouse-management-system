package com.sphwms.warehouse.internal.service;

import com.sphwms.shared.audit.AuditService;
import com.sphwms.shared.exception.BusinessException;
import com.sphwms.shared.exception.NotFoundException;
import com.sphwms.shared.security.CurrentUserProvider;
import com.sphwms.shared.sequence.IdSequenceService;
import com.sphwms.stock.internal.repository.StockBatchRepository;
import com.sphwms.warehouse.internal.dto.requests.WarehouseRequest;
import com.sphwms.warehouse.internal.dto.responses.WarehouseOptionResponse;
import com.sphwms.warehouse.internal.dto.responses.WarehouseResponse;
import com.sphwms.warehouse.internal.entity.Warehouse;
import com.sphwms.warehouse.internal.repository.WarehouseRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

/**
 * Unit tests for WarehouseService (create, update, status toggle, usage maths, search/filter).
 * All repositories are mocked, so no database is needed.
 * LENIENT strictness: remove the @MockitoSettings line to make Mockito also fail on unused stubs.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class WarehouseServiceTest {

    private static Validator validator;

    @Mock private WarehouseRepository warehouseRepository;
    @Mock private StockBatchRepository stockBatchRepository;
    @Mock private IdSequenceService idSequenceService;
    @Mock private CurrentUserProvider currentUserProvider;
    @Mock private AuditService auditService;
    @Mock private EntityManager entityManager;
    @InjectMocks private WarehouseService service;

    @BeforeAll
    static void initValidator() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    @BeforeEach
    void commonStubs() {
        when(currentUserProvider.getCurrentUserId()).thenReturn(1L);
        // save() returns whatever it was given
        when(warehouseRepository.save(any(Warehouse.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    // ------------------------------------------------------------------ helpers

    private Warehouse warehouse(long id, String code, String name, String location, String capacity, boolean active) {
        Warehouse w = new Warehouse();
        w.setWarehouseId(id);
        w.setCodeNumber((int) id);
        w.setCode(code);
        w.setName(name);
        w.setLocation(location);
        w.setInCharge("Old In-charge");
        w.setCapacityKg(new BigDecimal(capacity));
        w.setActive(active);
        return w;
    }

    private Warehouse warehouseA(String capacity) {
        return warehouse(1L, "WH-01", "Warehouse A", "Dhaka", capacity, true);
    }

    /** One row of stockBatchRepository.findStockSummaryByWarehouse(): [warehouseId, usedKg, stockAmount]. */
    private List<Object[]> stock(long warehouseId, String usedKg, String amount) {
        return Collections.singletonList(new Object[]{warehouseId, new BigDecimal(usedKg), new BigDecimal(amount)});
    }

    private WarehouseRequest request(String name, String capacity) {
        return new WarehouseRequest(name, "Dhaka", "Karim", new BigDecimal(capacity), "ACTIVE");
    }

    /** Fakes the "count pending arrivals" JPQL query used when deactivating. */
    private void givenPendingArrivals(long count) {
        Query query = mock(Query.class);
        when(entityManager.createQuery(anyString())).thenReturn(query);
        when(query.setParameter(eq("whId"), any())).thenReturn(query);
        when(query.getSingleResult()).thenReturn(count);
    }

    private static void assertBd(String expected, BigDecimal actual) {
        assertNotNull(actual);
        assertEquals(0, new BigDecimal(expected).compareTo(actual), "expected " + expected + " but was " + actual);
    }

    // ================================================================== CREATE

    // ------------------------------------------------------------------ NORMAL

    @Test
    void createWarehouse_valid_generatesCodeAndNormalizesText() {
        when(warehouseRepository.findByNameIgnoreCase("Warehouse E")).thenReturn(Optional.empty());
        when(idSequenceService.nextWarehouseCode())
                .thenReturn(new IdSequenceService.WarehouseCodeResult(5, "WH-05"));

        WarehouseResponse res = service.createWarehouse(
                new WarehouseRequest("  Warehouse   E ", " Dhaka ", "Karim", new BigDecimal("5000"), null));

        ArgumentCaptor<Warehouse> saved = ArgumentCaptor.forClass(Warehouse.class);
        verify(warehouseRepository).save(saved.capture());
        assertEquals("WH-05", saved.getValue().getCode());
        assertEquals(5, saved.getValue().getCodeNumber());
        assertEquals("Warehouse E", saved.getValue().getName());   // trimmed + single spaces
        assertEquals("Dhaka", saved.getValue().getLocation());
        assertTrue(saved.getValue().getActive());

        assertEquals("WH-05", res.code());
        assertEquals("ACTIVE", res.status());
        assertBd("0", res.usedKg());
        assertBd("0", res.stockAmount());
        assertEquals(0, res.usedPercent());
        verify(auditService).log(eq("WAREHOUSE_CREATE"), eq("WAREHOUSE"), any(), anyString());
    }

    @Test
    void createWarehouse_blankInCharge_usesDefaultText() {
        when(warehouseRepository.findByNameIgnoreCase("Warehouse E")).thenReturn(Optional.empty());
        when(idSequenceService.nextWarehouseCode())
                .thenReturn(new IdSequenceService.WarehouseCodeResult(5, "WH-05"));

        service.createWarehouse(new WarehouseRequest("Warehouse E", "Dhaka", "   ", new BigDecimal("5000"), "ACTIVE"));

        ArgumentCaptor<Warehouse> saved = ArgumentCaptor.forClass(Warehouse.class);
        verify(warehouseRepository).save(saved.capture());
        assertEquals("Warehouse In-charge", saved.getValue().getInCharge());
    }

    @ParameterizedTest(name = "status \"{0}\" -> active = {1}")
    @CsvSource(value = {"NULL,true", "ACTIVE,true", "anything,true", "INACTIVE,false", "inactive,false"}, nullValues = "NULL")
    void createWarehouse_statusText_decidesActiveFlag(String status, boolean expectedActive) {
        when(warehouseRepository.findByNameIgnoreCase("Warehouse E")).thenReturn(Optional.empty());
        when(idSequenceService.nextWarehouseCode())
                .thenReturn(new IdSequenceService.WarehouseCodeResult(5, "WH-05"));

        service.createWarehouse(new WarehouseRequest("Warehouse E", "Dhaka", "Karim", new BigDecimal("5000"), status));

        ArgumentCaptor<Warehouse> saved = ArgumentCaptor.forClass(Warehouse.class);
        verify(warehouseRepository).save(saved.capture());
        assertEquals(expectedActive, saved.getValue().getActive());
    }

    // ------------------------------------------------------------------ BOUNDARY / EXCEPTIONAL

    @Test
    void createWarehouse_duplicateNameWithDifferentCase_throwsAndSavesNothing() {
        // repository does a case-insensitive lookup: "warehouse a" matches "Warehouse A"
        when(warehouseRepository.findByNameIgnoreCase("warehouse a"))
                .thenReturn(Optional.of(warehouseA("12000")));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.createWarehouse(request("warehouse a", "5000")));

        assertEquals("Warehouse name already exists.", ex.getMessage());
        verify(warehouseRepository, never()).save(any());
        verifyNoInteractions(idSequenceService);   // no code number is wasted
        verifyNoInteractions(auditService);
    }

    // ================================================================== UPDATE

    // ------------------------------------------------------------------ NORMAL

    @Test
    void updateWarehouse_valid_changesFieldsButKeepsCode() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(w));
        when(warehouseRepository.findByNameIgnoreCaseAndIdNot("Warehouse A2", 1L)).thenReturn(Optional.empty());
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(stock(1L, "7440", "446400"));

        WarehouseResponse res = service.updateWarehouse(1L,
                new WarehouseRequest("Warehouse A2", " Gazipur ", "Rahim", new BigDecimal("15000"), "ACTIVE"));

        assertEquals("WH-01", w.getCode());                 // code is read-only
        assertEquals("Warehouse A2", w.getName());
        assertEquals("Gazipur", w.getLocation());
        assertEquals("Rahim", w.getInCharge());
        assertBd("15000", w.getCapacityKg());
        assertNotNull(w.getUpdatedAt());
        assertEquals(1L, w.getUpdatedBy());
        assertBd("7440", res.usedKg());
        verify(auditService).log(eq("WAREHOUSE_UPDATE"), eq("WAREHOUSE"), any(), anyString());
    }

    @Test
    void updateWarehouse_blankInCharge_keepsOldInCharge() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(w));
        when(warehouseRepository.findByNameIgnoreCaseAndIdNot("Warehouse A", 1L)).thenReturn(Optional.empty());

        service.updateWarehouse(1L, new WarehouseRequest("Warehouse A", "Dhaka", "  ", new BigDecimal("12000"), null));

        assertEquals("Old In-charge", w.getInCharge());
    }

    // ------------------------------------------------------------------ BOUNDARY

    @Test
    void updateWarehouse_capacityEqualToCurrentStock_isAllowed() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(w));
        when(warehouseRepository.findByNameIgnoreCaseAndIdNot("Warehouse A", 1L)).thenReturn(Optional.empty());
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(stock(1L, "7440", "446400"));

        WarehouseResponse res = service.updateWarehouse(1L, request("Warehouse A", "7440"));

        assertBd("7440", w.getCapacityKg());
        assertEquals(100, res.usedPercent());
        assertBd("0", res.freeKg());
    }

    @Test
    void updateWarehouse_capacityOnePaisaBelowCurrentStock_isRejected() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(w));
        when(warehouseRepository.findByNameIgnoreCaseAndIdNot("Warehouse A", 1L)).thenReturn(Optional.empty());
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(stock(1L, "7440", "446400"));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.updateWarehouse(1L, request("Warehouse A", "7439.99")));

        assertEquals("Capacity cannot be less than current stock (7440 kg).", ex.getMessage());
        assertBd("12000", w.getCapacityKg());                // unchanged
        verify(warehouseRepository, never()).save(any());
        verifyNoInteractions(auditService);
    }

    @Test
    void updateWarehouse_warehouseWithNoStock_acceptsSmallCapacity() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(w));
        when(warehouseRepository.findByNameIgnoreCaseAndIdNot("Warehouse A", 1L)).thenReturn(Optional.empty());
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(Collections.emptyList());

        service.updateWarehouse(1L, request("Warehouse A", "0.01"));

        assertBd("0.01", w.getCapacityKg());
    }

    // ------------------------------------------------------------------ EXCEPTIONAL

    @Test
    void updateWarehouse_nameUsedByAnotherWarehouse_throws() {
        Warehouse w = warehouseA("12000");
        Warehouse other = warehouse(2L, "WH-02", "Warehouse B", "Dhaka", "8000", true);
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(w));
        when(warehouseRepository.findByNameIgnoreCaseAndIdNot("warehouse b", 1L)).thenReturn(Optional.of(other));

        BusinessException ex = assertThrows(BusinessException.class,
                () -> service.updateWarehouse(1L, request("warehouse b", "12000")));

        assertEquals("Warehouse name already exists.", ex.getMessage());
        verify(warehouseRepository, never()).save(any());
    }

    @Test
    void updateWarehouse_unknownId_throwsNotFound() {
        when(warehouseRepository.findById(99L)).thenReturn(Optional.empty());

        NotFoundException ex = assertThrows(NotFoundException.class,
                () -> service.updateWarehouse(99L, request("Warehouse A", "12000")));

        assertEquals("Warehouse not found.", ex.getMessage());
        verify(warehouseRepository, never()).save(any());
    }

    // ================================================================== DEACTIVATE / ACTIVATE

    @Test
    void toggleStatus_activeWarehouseWithNoStockAndNoPending_becomesInactive() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findByIdWithLock(1L)).thenReturn(Optional.of(w));
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(Collections.emptyList());
        givenPendingArrivals(0L);

        WarehouseResponse res = service.toggleStatus(1L);

        assertFalse(w.getActive());
        assertEquals("INACTIVE", res.status());
        verify(auditService).log(eq("WAREHOUSE_STATUS"), eq("WAREHOUSE"), any(), anyString());
    }

    @Test
    void toggleStatus_stockExactlyZeroRow_isTreatedAsEmpty() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findByIdWithLock(1L)).thenReturn(Optional.of(w));
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(stock(1L, "0", "0"));
        givenPendingArrivals(0L);

        service.toggleStatus(1L);

        assertFalse(w.getActive());
    }

    @Test
    void toggleStatus_smallestPositiveStock_blocksDeactivation() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findByIdWithLock(1L)).thenReturn(Optional.of(w));
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(stock(1L, "0.01", "1"));

        BusinessException ex = assertThrows(BusinessException.class, () -> service.toggleStatus(1L));

        assertEquals("Cannot deactivate: warehouse still has stock.", ex.getMessage());
        assertTrue(w.getActive());
        verify(warehouseRepository, never()).save(any());
        verifyNoInteractions(entityManager);                 // stock check fails first
    }

    @Test
    void toggleStatus_pendingArrivalsExist_blocksDeactivation() {
        Warehouse w = warehouseA("12000");
        when(warehouseRepository.findByIdWithLock(1L)).thenReturn(Optional.of(w));
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(Collections.emptyList());
        givenPendingArrivals(2L);

        BusinessException ex = assertThrows(BusinessException.class, () -> service.toggleStatus(1L));

        assertEquals("Cannot deactivate: pending arrivals exist.", ex.getMessage());
        assertTrue(w.getActive());
        verify(warehouseRepository, never()).save(any());
    }

    @Test
    void toggleStatus_inactiveWarehouse_canAlwaysBeActivatedWithoutChecks() {
        Warehouse w = warehouse(4L, "WH-04", "Warehouse D", "Khulna", "5000", false);
        when(warehouseRepository.findByIdWithLock(4L)).thenReturn(Optional.of(w));

        WarehouseResponse res = service.toggleStatus(4L);

        assertTrue(w.getActive());
        assertEquals("ACTIVE", res.status());
        verifyNoInteractions(entityManager);                 // no pending-arrival query when activating
    }

    @Test
    void toggleStatus_unknownId_throwsNotFound() {
        when(warehouseRepository.findByIdWithLock(99L)).thenReturn(Optional.empty());

        NotFoundException ex = assertThrows(NotFoundException.class, () -> service.toggleStatus(99L));

        assertEquals("Warehouse not found.", ex.getMessage());
    }

    // ================================================================== USAGE MATHS (getWarehouseById)

    /** capacity, used, expected percent (rounded DOWN), expected free kg (never below 0). */
    @ParameterizedTest(name = "capacity {0} kg, used {1} kg -> {2}% used, free {3} kg")
    @CsvSource({
            "12000, 7440, 62, 4560",     // example from the screenshot
            "1000,  0,    0,  1000",     // empty
            "1000,  1,    0,  999",      // 0.1% rounds down to 0
            "1000,  996,  99, 4",        // 99.6% must NOT show as 100%
            "1000,  1000, 100, 0",       // exactly full
            "1000,  1200, 120, 0"        // over capacity: free kg is clamped at 0
    })
    void getWarehouseById_usageMath_roundsDownAndClampsFreeSpace(
            String capacity, String used, int expectedPercent, String expectedFree) {
        when(warehouseRepository.findById(1L)).thenReturn(Optional.of(warehouseA(capacity)));
        when(stockBatchRepository.findStockSummaryByWarehouse()).thenReturn(stock(1L, used, "1000"));

        WarehouseResponse res = service.getWarehouseById(1L);

        assertEquals(expectedPercent, res.usedPercent());
        assertBd(expectedFree, res.freeKg());
        assertBd(used, res.usedKg());
    }

    @Test
    void getWarehouseById_unknownId_throwsNotFound() {
        when(warehouseRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> service.getWarehouseById(99L));
    }

    // ================================================================== LIST / SEARCH / OPTIONS

    private void givenFourWarehousesWithOneInactive() {
        when(warehouseRepository.findAllByOrderByCodeNumberAsc()).thenReturn(Arrays.asList(
                warehouse(1L, "WH-01", "Warehouse A", "Dhaka", "12000", true),
                warehouse(2L, "WH-02", "Warehouse B", "Chattogram", "8000", true),
                warehouse(3L, "WH-03", "Warehouse C", "Dhaka Savar", "5000", true),
                warehouse(4L, "WH-04", "Warehouse D", "Khulna", "5000", false)));
    }

    private static List<String> codes(List<WarehouseResponse> list) {
        return list.stream().map(WarehouseResponse::code).collect(Collectors.toList());
    }

    @Test
    void getAllWarehouses_noFilter_returnsEveryWarehouseInCodeOrder() {
        givenFourWarehousesWithOneInactive();

        assertEquals(List.of("WH-01", "WH-02", "WH-03", "WH-04"), codes(service.getAllWarehouses(null, null)));
        assertEquals(4, service.getAllWarehouses("  ", "ALL").size());
    }

    @Test
    void getAllWarehouses_statusFilter_keepsOnlyMatchingStatus() {
        givenFourWarehousesWithOneInactive();

        assertEquals(List.of("WH-01", "WH-02", "WH-03"), codes(service.getAllWarehouses("", "active")));
        assertEquals(List.of("WH-04"), codes(service.getAllWarehouses("", "INACTIVE")));
    }

    @Test
    void getAllWarehouses_searchByNameCodeOrLocation_isCaseInsensitiveAndTrimmed() {
        givenFourWarehousesWithOneInactive();

        assertEquals(List.of("WH-01", "WH-03"), codes(service.getAllWarehouses("  DHAKA ", "ALL")));   // location
        assertEquals(List.of("WH-02"), codes(service.getAllWarehouses("wh-02", "ALL")));              // code
        assertEquals(List.of("WH-04"), codes(service.getAllWarehouses("warehouse d", "ALL")));        // name
    }

    @Test
    void getAllWarehouses_searchAndStatusTogether_bothApply() {
        givenFourWarehousesWithOneInactive();

        assertEquals(List.of("WH-01", "WH-03"), codes(service.getAllWarehouses("dhaka", "ACTIVE")));
        assertTrue(service.getAllWarehouses("khulna", "ACTIVE").isEmpty());
    }

    @Test
    void getAllWarehouses_noMatch_returnsEmptyListNotError() {
        givenFourWarehousesWithOneInactive();

        assertTrue(service.getAllWarehouses("nothing-like-this", "ALL").isEmpty());
    }

    @Test
    void getNextCode_returnsPreviewFromSequence() {
        when(idSequenceService.peekWarehouseCode()).thenReturn("WH-05");

        Map<String, String> res = service.getNextCode();

        assertEquals("WH-05", res.get("code"));
        verify(idSequenceService, never()).nextWarehouseCode();   // preview must not consume a number
    }

    @Test
    void getWarehouseOptions_excludesInactiveUnlessAsked() {
        Warehouse active = warehouse(1L, "WH-01", "Warehouse A", "Dhaka", "12000", true);
        Warehouse inactive = warehouse(4L, "WH-04", "Warehouse D", "Khulna", "5000", false);
        when(warehouseRepository.findByActiveTrueOrderByCodeNumberAsc()).thenReturn(List.of(active));
        when(warehouseRepository.findAllByOrderByCodeNumberAsc()).thenReturn(List.of(active, inactive));

        List<WarehouseOptionResponse> onlyActive = service.getWarehouseOptions(false);
        List<WarehouseOptionResponse> all = service.getWarehouseOptions(true);

        assertEquals(1, onlyActive.size());
        assertTrue(onlyActive.get(0).active());
        assertEquals(2, all.size());
        assertFalse(all.get(1).active());
    }

    // ================================================================== INVALID INPUT (bean validation on the request)

    private static Set<String> messages(Set<ConstraintViolation<WarehouseRequest>> violations) {
        return violations.stream().map(ConstraintViolation::getMessage).collect(Collectors.toSet());
    }

    @Test
    void warehouseRequest_blankNameAndLocation_reportsBothMessages() {
        WarehouseRequest bad = new WarehouseRequest(" ", "", "Karim", new BigDecimal("100"), null);

        assertEquals(Set.of("Warehouse name is required.", "Location is required."),
                messages(validator.validate(bad)));
    }

    @ParameterizedTest(name = "capacity {0} is rejected")
    @CsvSource(value = {"0", "-1", "-0.01"})
    void warehouseRequest_zeroOrNegativeCapacity_isRejected(String capacity) {
        WarehouseRequest bad = new WarehouseRequest("Warehouse E", "Dhaka", "Karim", new BigDecimal(capacity), null);

        assertEquals(Set.of("Capacity must be greater than zero."), messages(validator.validate(bad)));
    }

    @Test
    void warehouseRequest_missingCapacity_isRejected() {
        WarehouseRequest bad = new WarehouseRequest("Warehouse E", "Dhaka", "Karim", null, null);

        assertEquals(Set.of("Capacity must be greater than zero."), messages(validator.validate(bad)));
    }

    @Test
    void warehouseRequest_smallestValidCapacityAndOptionalFieldsMissing_passes() {
        WarehouseRequest ok = new WarehouseRequest("Warehouse E", "Dhaka", null, new BigDecimal("0.01"), null);

        assertTrue(validator.validate(ok).isEmpty());
    }
}
