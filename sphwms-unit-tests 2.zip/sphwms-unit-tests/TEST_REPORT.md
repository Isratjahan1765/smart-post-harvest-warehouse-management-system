# Section 11 - Unit Testing (Test Coverage and Quality)

Tools: JUnit 5, Mockito (repositories are mocked, no database), Jakarta Bean Validation, JaCoCo (coverage).
Run: `mvn clean test` then open `target/site/jacoco/index.html`.

Four services are tested: AuthService, WarehouseService, ArrivalService, SaleService
(about 109 test cases, because the parameterized tests run once per value).

Every service has all four kinds of case:

| Kind | Meaning | Example from this project |
|---|---|---|
| Normal | Correct data gives the correct result | Valid sale with full payment becomes PAID and stock drops 500 -> 400 |
| Boundary | Exactly on / one step beside a limit | paid = total (PAID) vs total + 0.01 (error); quantity = stock vs stock + 0.01; 4th vs 5th wrong password |
| Invalid input | Wrong or missing data | Quantity 0 / -1, blank name, expiry date today, blank rejection reason |
| Exceptional | Something goes wrong in the system | Unknown id, inactive warehouse, already confirmed arrival, locked account |

## 1. AuthService (`AuthServiceTest`)

| Test | Kind | What it verifies |
|---|---|---|
| login_validCredentials_returnsTokenAndResetsFailedAttempts | Normal | Correct password gives a token, expiry 1800 s, failed attempts reset to 0, last login saved |
| login_roleWithSpaces_isNormalizedToUpperSnakeCase | Normal | "Warehouse Manager" becomes WAREHOUSE_MANAGER in the token and response |
| login_usernameWithSurroundingSpaces_isTrimmed | Normal | "  manager  " still finds the user |
| login_wrongPassword_countsAttemptsAndLocksOnFifth (0->1, 3->4, 4->5) | Boundary | Attempts increase by one; account stays ACTIVE at 4 and becomes LOCKED at exactly 5 |
| login_statusInLowerCase_stillTreatedAsActive | Boundary | Status check ignores letter case |
| login_unknownUser_returnsSameGenericMessageAsWrongPassword | Invalid | Unknown user gets 401 with the same message as a wrong password (no user guessing) |
| loginRequest_blank / null / valid (3 tests) | Invalid | Bean validation messages "Username is required." / "Password is required." |
| login_nonActiveAccount_isRejectedEvenWithCorrectPassword (LOCKED, BLOCKED, INACTIVE) | Exceptional | 403 with the locked message, password is never checked, no token issued |
| me_existingUser_returnsInfoWithEmptyStringsForMissingEmailAndPhone | Boundary | Null email/phone become "" instead of null |
| me_unknownUser_throwsUnauthorized | Exceptional | Token of a deleted user gives 401 |

## 2. WarehouseService (`WarehouseServiceTest`)

| Test | Kind | What it verifies |
|---|---|---|
| createWarehouse_valid_generatesCodeAndNormalizesText | Normal | Next code WH-05 is used, name "  Warehouse   E " is saved as "Warehouse E", new warehouse is active with 0 stock, audit logged |
| createWarehouse_statusText_decidesActiveFlag (5 values) | Boundary | Only INACTIVE (any case) makes it inactive; null or other text means active |
| createWarehouse_duplicateNameWithDifferentCase_throwsAndSavesNothing | Exceptional | "warehouse a" is a duplicate of "Warehouse A"; nothing saved, no code number wasted |
| updateWarehouse_valid_changesFieldsButKeepsCode | Normal | Name, location, in-charge, capacity change; code stays WH-01; updated_by/at set |
| updateWarehouse_capacityEqualToCurrentStock_isAllowed | Boundary | Capacity = stock (7440) is allowed, shown as 100% used |
| updateWarehouse_capacityOnePaisaBelowCurrentStock_isRejected | Boundary | 7439.99 is rejected with the capacity message; old capacity kept; nothing saved |
| updateWarehouse_nameUsedByAnotherWarehouse_throws / unknownId | Exceptional | Duplicate name of another warehouse and unknown id (404) |
| toggleStatus_stockExactlyZeroRow / smallestPositiveStock | Boundary | 0 kg can be deactivated, 0.01 kg cannot |
| toggleStatus_pendingArrivalsExist_blocksDeactivation | Exceptional | Pending arrivals block deactivation |
| toggleStatus_inactiveWarehouse_canAlwaysBeActivated | Normal | Activation needs no stock or pending check |
| getWarehouseById_usageMath (6 rows: 62%, 0%, 0%, 99%, 100%, 120%) | Boundary | Used % rounds down (99.6% shows 99, not 100); free kg never below 0 |
| getAllWarehouses_* (5 tests) | Normal / Boundary | Search by name, code, location (case-insensitive, trimmed) and status filter work alone and together; no match gives an empty list |
| warehouseRequest_* (5 tests) | Invalid | Blank name/location, capacity 0, -1, -0.01, null are rejected with the exact messages; 0.01 is the smallest valid capacity |

## 3. ArrivalService (`ArrivalServiceTest`)

| Test | Kind | What it verifies |
|---|---|---|
| createArrival_valid_isPendingWithServerCalculatedCostAndNoStockChange | Normal | Status PENDING, price copied from the product (60, client value ignored), total = 500 x 60, stock NOT touched |
| createArrival_expiryTomorrow / Today / Yesterday | Boundary | Tomorrow accepted; today and yesterday rejected with "Expiry date must be in the future." |
| createArrival_zeroOrNegativeQuantity (0, -1, -0.01), nullQuantity | Invalid | "Invalid quantity - enter a positive number."; nothing saved |
| createArrival_inactiveWarehouse / inactiveProduct / unknown product / unknown warehouse | Exceptional | Correct error message for each; nothing saved |
| confirmArrival_allChecksPass_confirmsAndCreatesStockBatchAndTransaction | Normal | Status CONFIRMED, stock batch (remaining = 500, cost 60), ARRIVAL transaction, quality check row, audit |
| confirmArrival_fillsWarehouseExactlyToCapacity_succeeds | Boundary | 500 used + 500 arrival = 1000 capacity is allowed |
| confirmArrival_exceedsCapacityByOnePaisa_isRejectedAndStockUntouched | Boundary | 1000.01 > 1000 is rejected; arrival stays PENDING; no batch, transaction or quality check saved |
| confirmArrival_anyOneCheckboxFalse (5 runs), checkboxMissing | Invalid | Each of the 5 quality checkboxes must be ticked; a missing value counts as unticked |
| confirmArrival_notPending (CONFIRMED, REJECTED) | Exceptional | "Arrival already confirmed." so stock cannot grow twice |
| confirmArrival_warehouseBecameInactive / warehouseMissing / unknownArrival | Exceptional | Correct error, stock untouched |
| rejectArrival_withReason_rejectsTrimsReasonAndLeavesStockAlone | Normal | Status REJECTED, reason trimmed, failed quality check recorded, no stock change |
| rejectArrival_blankReason ("", " ", spaces), nullBodyOrNullReason | Invalid | "Rejection reason is required." |
| rejectArrival_notPending, unknownArrival | Exceptional | "Arrival cannot be rejected." / 404 |
| getSummary_* (2 tests) | Normal / Boundary | Total = pending + confirmed + rejected; all zero when empty |
| arrivalRequest_* (5 tests) | Invalid | Bean validation for expiry date (today fails), quantity <= 0, missing required fields |

## 4. SaleService (`SaleServiceTest`)

| Test | Kind | What it verifies |
|---|---|---|
| createSale_fullPayment_isPaidAndStockIsReduced | Normal | 100 kg x 70 = 7000, PAID, batch 500 -> 400, cost price 60 saved for profit reports |
| createSale_partialPayment_isDueWithDefaultDueDateAfter15Days | Normal | Paid 3000 gives DUE with 4000 left and due date = sale date + 15 days |
| createSale_clientSentRateIsIgnored_priceComesFromProduct | Normal | Server price is used, a fake client rate is ignored |
| createSale_quantitySpansTwoBatches_takesEarliestExpiryFirstAndSavesAllocations | Normal | 100 kg uses 60 from the early batch and 40 from the next; 2 allocations and 2 SALE transactions |
| createSale_paidExactlyTotal / paidOnePaisaAboveTotal / paidOnePaisaBelowTotal | Boundary | 7000 = PAID; 7000.01 rejected; 6999.99 stays DUE with 0.01 due |
| createSale_quantityEqualsAllStock / quantityOnePaisaMoreThanStock | Boundary | 160 of 160 kg succeeds and leaves 0; 160.01 fails and no batch changes |
| createSale_saleDateToday_isAllowedAndTomorrowIsNot | Boundary | Future sale date is rejected |
| createSale_zeroOrNegativeQuantity (0, -1, -0.01), nullQuantity | Invalid | Rejected before any database lookup |
| createSale_inactiveBuyer / inactiveProduct / inactiveWarehouse | Invalid | Correct message; nothing saved |
| createSale_unknownBuyer / unknownProduct / unknownWarehouse | Exceptional | "... not found." and nothing saved |
| createSale_noSellableBatches_isInsufficientStock | Exceptional | Expired or empty stock gives "Insufficient stock for this sale." |
| cancelSale_returnsStockToEveryBatchItCameFrom | Normal | Allocations are returned to their own batches (60 and 40), SALE_CANCEL transactions written |
| cancelSale_alreadyCancelled / unknownSale / batchNoLongerExists | Exceptional | Stock is not returned twice; 404; a missing batch is skipped |
| getAllSales_dateRange (inclusive, from = to, from > to) | Boundary | Both ends included; from after to gives "Invalid date range." |

## Test-writing findings (2 real gaps in the code)

Writing the tests showed two missing checks. Both have a ready test that is marked `@Disabled`
(it would fail today). Apply the one-line fix, delete the `@Disabled` line and the test becomes active.

1. Arrival confirm with no request body skips the whole quality check (controller has `@RequestBody(required = false)`).
   Fix in `ArrivalService.confirmArrival`: `if (qcReq == null) throw new BusinessException("Arrival data is invalid - cannot confirm.");`
2. Sale accepts a negative `paidNow`.
   Fix in `SaleService.createSale` before the "paid > total" check:
   `if (paid.compareTo(BigDecimal.ZERO) < 0) throw new BusinessException("Paid amount cannot be negative.");`

Note: the capacity error message prints the number as the database gives it, for example "7440 kg",
while the feature document shows "7,440 kg". The test follows the code.
